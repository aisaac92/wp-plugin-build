<?php

defined( '\ABSPATH' ) || exit;

/*
  Name: Product card (no features)
 */

__( 'Product card (no features)', 'content-egg' );

$this->renderPartial( 'item_simple' );
