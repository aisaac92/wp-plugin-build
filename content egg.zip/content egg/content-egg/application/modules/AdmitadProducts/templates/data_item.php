<?php

defined( '\ABSPATH' ) || exit;
/*
  Name: Product card
 */

__( 'Product card', 'content-egg-tpl' );

$this->renderPartial( 'item' );
