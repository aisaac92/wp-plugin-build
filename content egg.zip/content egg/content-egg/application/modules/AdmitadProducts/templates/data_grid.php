<?php

defined( '\ABSPATH' ) || exit;
/*
  Name: Grid
 */

__( 'Grid', 'content-egg-tpl' );

$this->renderPartial( 'grid' );
