<?php

defined( '\ABSPATH' ) || exit;

/*
  Name: Description only
 */

__( 'Description only', 'content-egg-tpl' );

$this->renderPartial( 'description' );
